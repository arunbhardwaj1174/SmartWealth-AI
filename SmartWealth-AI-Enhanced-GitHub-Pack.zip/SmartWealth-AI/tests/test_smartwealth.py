import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "modules"))

from risk_profiler import risk_profile, score_from_answers
from sip_calculator import required_sip, future_value_sip
from portfolio_allocator import illustrative_allocation
from wealth_projection import project_sip, inflation_adjusted_value

def test_risk_bands():
    assert risk_profile(20) == "Conservative"
    assert risk_profile(45) == "Moderate"
    assert risk_profile(72) == "Moderate-Growth"
    assert risk_profile(90) == "Growth"

def test_questionnaire_conversion():
    assert score_from_answers([1, 3, 5]) == 50

def test_sip_target():
    sip = required_sip(5_000_000, 0.12, 15)
    assert 9500 < sip < 10500

def test_zero_return():
    assert future_value_sip(1000, 0.0, 1) == 12000

def test_allocation_sums_to_100():
    assert abs(sum(illustrative_allocation("Moderate-Growth").values()) - 1) < 1e-9

def test_projection():
    result = project_sip(10000, 12/100, 5)
    assert len(result["year"]) == 5
    assert result["value"][-1] > result["contribution"][-1]

def test_inflation():
    assert abs(inflation_adjusted_value(110, 0.10, 1) - 100) < 1e-9

"""SIP calculation utilities for an educational FinTech prototype."""

from typing import Dict

def _validate_inputs(target: float, annual_return: float, years: int) -> None:
    if target <= 0:
        raise ValueError("Target amount must be greater than zero.")
    if annual_return <= -1:
        raise ValueError("Annual return must be greater than -100%.")
    if years <= 0:
        raise ValueError("Years must be greater than zero.")

def monthly_rate(annual_return: float) -> float:
    """Convert nominal annual return to a monthly rate."""
    return annual_return / 12

def required_sip(target: float, annual_return: float, years: int) -> float:
    """Calculate monthly SIP required for a future target using an end-of-month SIP model."""
    _validate_inputs(target, annual_return, years)
    r = monthly_rate(annual_return)
    n = years * 12
    if abs(r) < 1e-12:
        return target / n
    return target * r / ((1 + r) ** n - 1)

def future_value_sip(monthly_sip: float, annual_return: float, years: int, due: bool = True) -> float:
    """Calculate future value of a monthly SIP. If due=True, deposits occur at month start."""
    if monthly_sip < 0 or years <= 0 or annual_return <= -1:
        raise ValueError("Invalid SIP, return, or time-horizon input.")
    r = monthly_rate(annual_return)
    n = years * 12
    if abs(r) < 1e-12:
        return monthly_sip * n
    fv = monthly_sip * (((1 + r) ** n - 1) / r)
    return fv * (1 + r) if due else fv

def sip_breakdown(monthly_sip: float, annual_return: float, years: int) -> Dict[str, float]:
    """Return contribution, estimated gain, and future value."""
    fv = future_value_sip(monthly_sip, annual_return, years)
    contribution = monthly_sip * years * 12
    return {
        "monthly_sip": monthly_sip,
        "total_contribution": contribution,
        "estimated_gain": fv - contribution,
        "future_value": fv,
    }

"""Wealth projection and scenario-analysis utilities."""

from typing import Dict, Iterable
import numpy as np

from sip_calculator import future_value_sip

def project_sip(monthly_sip: float, annual_return: float, years: int) -> Dict[str, np.ndarray]:
    """Create a yearly SIP projection with contributions and estimated gains."""
    if monthly_sip < 0 or years <= 0:
        raise ValueError("Monthly SIP must be non-negative and years must be positive.")
    year_axis = np.arange(1, years + 1)
    values = np.array([future_value_sip(monthly_sip, annual_return, int(y)) for y in year_axis])
    contributions = monthly_sip * 12 * year_axis
    return {
        "year": year_axis,
        "value": values,
        "contribution": contributions,
        "gain": values - contributions,
    }

def scenario_projection(monthly_sip: float, years: int, scenarios: Dict[str, float] | None = None) -> Dict[str, Dict[str, np.ndarray]]:
    """Project optimistic, expected, and conservative return scenarios."""
    if scenarios is None:
        scenarios = {"Optimistic": .15, "Expected": .12, "Conservative": .08}
    return {name: project_sip(monthly_sip, rate, years) for name, rate in scenarios.items()}

def inflation_adjusted_value(amount: float, annual_inflation: float, years: int) -> float:
    """Return today's purchasing-power equivalent of a future amount."""
    if amount < 0 or annual_inflation < -1 or years < 0:
        raise ValueError("Invalid amount, inflation, or years.")
    return amount / ((1 + annual_inflation) ** years)

"""Illustrative portfolio allocation rules."""

from typing import Dict

PLANS: Dict[str, Dict[str, float]] = {
    "Conservative": {"Equity": .35, "Debt": .45, "Gold": .10, "Cash": .10},
    "Moderate": {"Equity": .50, "Debt": .35, "Gold": .10, "Cash": .05},
    "Moderate-Growth": {"Equity": .60, "Debt": .25, "Gold": .10, "Cash": .05},
    "Growth": {"Equity": .65, "Debt": .20, "Gold": .10, "Cash": .05},
}

def illustrative_allocation(profile: str) -> Dict[str, float]:
    """Return the project's illustrative allocation for a risk profile."""
    if profile not in PLANS:
        raise ValueError(f"Unknown profile: {profile}. Choose from {list(PLANS)}")
    return PLANS[profile].copy()

def allocation_amounts(profile: str, portfolio_value: float) -> Dict[str, float]:
    """Convert allocation percentages into rupee amounts."""
    if portfolio_value < 0:
        raise ValueError("Portfolio value cannot be negative.")
    return {asset: weight * portfolio_value for asset, weight in illustrative_allocation(profile).items()}

def allocation_dataframe(profile: str, portfolio_value: float = 0):
    """Return a Pandas DataFrame suitable for notebook/dashboard display."""
    import pandas as pd
    allocation = illustrative_allocation(profile)
    amounts = allocation_amounts(profile, portfolio_value)
    return pd.DataFrame({
        "Asset Class": list(allocation.keys()),
        "Allocation": [v * 100 for v in allocation.values()],
        "Amount (₹)": [amounts[k] for k in allocation],
    })

"""Risk profiling utilities for the SmartWealth AI academic prototype."""

from typing import Dict, List, Tuple

RISK_BANDS: List[Tuple[int, int, str]] = [
    (0, 34, "Conservative"),
    (35, 54, "Moderate"),
    (55, 79, "Moderate-Growth"),
    (80, 100, "Growth"),
]

def validate_score(score: float) -> float:
    """Validate and normalize a 0-100 risk score."""
    if isinstance(score, bool):
        raise TypeError("Risk score must be a number, not True/False.")
    score = float(score)
    if not 0 <= score <= 100:
        raise ValueError("Risk score must be between 0 and 100.")
    return score

def risk_profile(score: float) -> str:
    """Map a 0-100 score to an explainable risk profile."""
    score = validate_score(score)
    for low, high, label in RISK_BANDS:
        if low <= score <= high:
            return label
    raise ValueError("Unable to classify risk score.")

def risk_summary(score: float) -> Dict[str, object]:
    """Return a compact risk-profile summary for dashboards/notebooks."""
    score = validate_score(score)
    profile = risk_profile(score)
    descriptions = {
        "Conservative": "Capital stability is emphasized; volatility tolerance is relatively low.",
        "Moderate": "A balanced approach is used, combining growth and stability.",
        "Moderate-Growth": "The approach targets long-term growth while retaining diversification.",
        "Growth": "The approach accepts higher volatility in pursuit of long-term growth.",
    }
    return {"score": score, "profile": profile, "description": descriptions[profile]}

def score_from_answers(answers: List[int]) -> int:
    """Convert questionnaire answers (1-5) into a 0-100 score."""
    if not answers or any(a not in range(1, 6) for a in answers):
        raise ValueError("Answers must be a non-empty list containing values from 1 to 5.")
    average = sum(answers) / len(answers)
    return round((average - 1) / 4 * 100)

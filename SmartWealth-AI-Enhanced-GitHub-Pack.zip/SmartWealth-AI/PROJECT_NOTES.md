# Project Notes

## Suggested GitHub / LinkedIn screenshots
1. SmartWealth AI hero dashboard
2. Risk profile score and risk-band chart
3. SIP scenario comparison table
4. Asset allocation table + pie chart
5. Wealth projection scenario chart
6. Goal progress + inflation-awareness output

## Suggested viva explanation

SmartWealth AI is a rules-based academic FinTech prototype. It does not contain a trained AI/ML model. The “AI-style” layer explains deterministic calculations in plain language. A production system would require validated financial models, current data, suitability/compliance controls, privacy and security, extensive testing, and human oversight.

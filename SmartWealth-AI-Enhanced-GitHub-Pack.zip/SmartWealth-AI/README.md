# 💰 SmartWealth AI – Personalized Investment & Goal Planner

![SmartWealth AI Dashboard](assets/SmartWealth_AI_Hero_Banner.png)

**BBA FinTech & AI | Academic Project**

SmartWealth AI is an educational FinTech prototype that demonstrates how a robo-advisor-style workflow can connect **risk profiling, financial goals, SIP planning, illustrative asset allocation, scenario-based wealth projection, inflation awareness and explainable insights**.

## 🚀 Features

- 📊 0–100 risk profiling with transparent rule bands
- 🎯 Goal-based monthly SIP calculation
- 💼 Profile-driven illustrative asset allocation
- 📈 Contribution vs. estimated-gain analysis
- 🔮 Conservative / expected / optimistic scenario projections
- 🧮 Inflation-adjusted purchasing-power calculation
- 🤖 Explainable, deterministic AI-style insight layer
- ☁️ Google Colab / Jupyter notebook
- 🧪 Automated unit tests for core calculations

## 🧠 Project Workflow

```text
Investor Inputs
      ↓
Risk Score → Risk Profile
      ↓
Financial Goal + Return Assumption + Time Horizon
      ↓
Required SIP
      ↓
Illustrative Asset Allocation
      ↓
Scenario-Based Wealth Projection
      ↓
Explainable Insights
```

## 📁 Project Structure

```text
SmartWealth-AI/
├── README.md
├── PROJECT_NOTES.md
├── requirements.txt
├── data/
│   └── investment_data.csv
├── modules/
│   ├── __init__.py
│   ├── risk_profiler.py
│   ├── sip_calculator.py
│   ├── portfolio_allocator.py
│   └── wealth_projection.py
├── notebooks/
│   └── SmartWealth_AI_Colab.ipynb
├── tests/
│   └── test_smartwealth.py
└── assets/
    └── SmartWealth_AI_Hero_Banner.png
```

## ▶️ Run Locally

```bash
pip install -r requirements.txt
python -m pytest tests/
```

For the notebook, open `notebooks/SmartWealth_AI_Colab.ipynb` in Jupyter or Google Colab. If using Colab, upload/clone the complete repository so the `data/` and `modules/` folders are available.

## 📊 Main Modules

| Module | Purpose |
|---|---|
| `risk_profiler.py` | Score validation, profile mapping and questionnaire conversion |
| `sip_calculator.py` | Required SIP, future value and contribution/gain breakdown |
| `portfolio_allocator.py` | Illustrative profile-based asset allocation |
| `wealth_projection.py` | Year-by-year projections, scenarios and inflation adjustment |

## ⚠️ Important Disclaimer

This project is an **academic/educational prototype**. The return assumptions, allocations and projections are illustrative. They are **not financial advice, investment recommendations, guarantees or predictions of actual market performance**.
